# react-scroll-kit

Router-aware scroll management for React applications.

Automatic scroll restoration, navigation-aware scrolling, reusable hooks, utilities, and optional UI components for React Router apps.

---

## 1. Installation

Install the package via npm, yarn, or pnpm. Ensure that you have the peer dependencies `react` and `react-router-dom` installed.

```bash
npm install react-scroll-kit
```

---

## 2. Quick Start

Place the `<ScrollToTop />` component inside your React Router context (typically wrapping your main routes) to automatically reset scrolls on navigation:

```tsx
import { ScrollToTop } from 'react-scroll-kit';

// Place inside your router layout or root component
<ScrollToTop />
```

---

## 3. Utilities API

`react-scroll-kit` exports powerful utility functions for programmatic scrolling and scroll locking.

### `scrollTo`
Programmatically scroll the viewport or a specific container to a designated location.
```tsx
import { scrollTo } from 'react-scroll-kit';

scrollTo('#contact', {
  behavior: 'smooth',
  duration: 700,
  easing: 'easeOutExpo',
  offset: 80,
  scrollAxis: 'y'
});
```
| Option | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `behavior` | `'smooth' \| 'instant'` | `'instant'` | Scroll behavior. |
| `duration` | `number` | `500` | Custom animation duration in ms. |
| `easing` | `string \| Function` | `'easeOutQuad'` | Custom easing preset or function. |
| `offset` | `number` | `0` | Vertical offset in pixels (useful for sticky headers). |
| `delay` | `number` | `0` | Delay in ms before triggering the scroll. |
| `scrollAxis` | `'x' \| 'y' \| 'both'` | `'y'` | Axis to scroll. |
| `container` | `HTMLElement \| RefObject` | `window` | Specific scrollable container. |
| `respectReducedMotion` | `boolean` | `true` | Falls back to `'instant'` if user prefers reduced motion. |

### `hashScroll`
Smoothly scrolls to the element corresponding to the URL hash, retrying lookup up to 10 times in case the DOM is rendering asynchronously.
```tsx
import { hashScroll } from 'react-scroll-kit';
hashScroll('#my-section', 50); // scrolls with 50px offset
```

### `lockScroll` / `unlockScroll`
Locks the body scroll. Useful for modals, sidebars, and drawers. Properly handles iOS Safari quirks and preserves scroll position.
```tsx
import { lockScroll, unlockScroll, isScrollLocked } from 'react-scroll-kit';

// When opening modal
lockScroll();

// When closing modal
unlockScroll();
```

---

## 4. Component API

### `<ScrollToTop />`
Resets the viewport scroll position on route transitions.

| Prop | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `behavior` | `'smooth' \| 'instant'` | `'instant'` | Viewport scroll transition style. |
| `duration` | `number` | `500` | Custom animation duration in ms (if behavior is smooth). |
| `easing` | `string \| Function` | `'easeOutQuad'` | Easing preset or custom function. |
| `delay` | `number` | `0` | Timeout delay in ms before triggering the scroll. |
| `scrollAxis` | `'x' \| 'y' \| 'both'` | `'y'` | Axis to reset. |
| `container` | `HTMLElement \| RefObject` | `window` | Target container to scroll instead of window. |
| `excludeRoutes` | `string[]` | `[]` | Routes where top-scrolling is bypassed. Supports exact/prefix matches. |
| `respectReducedMotion` | `boolean` | `true` | Falls back to instant scroll if requested by OS. |

```tsx
<ScrollToTop 
  behavior="smooth" 
  duration={700}
  easing="easeOutExpo"
  scrollAxis="both"
  container={contentRef}
  respectReducedMotion={true}
/>
```

---

### `<ScrollRestoration />`
Stores scroll positions in `sessionStorage` and restores them on back/forward browser actions.

| Prop | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `delay` | `number` | `0` | Delay in ms before restoring positions. |
| `debounceMs` | `number` | `150` | Debounce time in ms before writing coordinates to sessionStorage. |
| `storageKey` | `string` | `'rstr'` | Base key name used to store scroll coordinates in storage. |
| `container` | `HTMLElement \| RefObject` | `window` | Target container to restore scroll for. |

```tsx
<ScrollRestoration storageKey="my-app-scroll" container={mainRef} />
```

---

### `<ScrollProgressBar />`
Renders a viewport progress bar representing reading/scroll percentage.

| Prop | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `height` | `string \| number` | `3` | Bar thickness in pixels (or string with units). |
| `color` | `string` | `'#1565C0'` | Bar color (accepts solid colors, gradients, etc.). |
| `zIndex` | `number` | `9999` | Stack order index of the bar. |
| `position` | `'top' \| 'bottom'` | `'top'` | Bar attachment placement. |
| `container` | `HTMLElement \| RefObject` | `window` | Scroll container to track. |

```tsx
<ScrollProgressBar color="linear-gradient(to right, #3b82f6, #10b981)" container={contentRef} />
```

---

### `<ScrollToTopButton />`
A floating action button that toggles visibility once scroll threshold is crossed.

| Prop | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `threshold` | `number` | `300` | Minimum scroll height in pixels before becoming visible. |
| `behavior` | `'smooth' \| 'instant'` | `'smooth'` | Scroll behavior applied when clicked. |
| `enableKeyboardNavigation` | `boolean` | `true` | Enables focusing and triggering via Enter/Space. |
| `respectReducedMotion` | `boolean` | `true` | Falls back to instant scroll if requested by OS. |
| `showLabel` | `boolean` | `false` | Shows a text label under the button. |

```tsx
<ScrollToTopButton threshold={400} enableKeyboardNavigation />
```

---

### `<ScrollLink />`
Wraps React Router's `<Link>` to scroll to specific coordinates or selectors when navigated.

```tsx
<ScrollLink to="/about#pricing" scrollTo="#pricing" scrollBehavior="smooth">
  Go to Pricing
</ScrollLink>
```

---

## 5. Hook Examples

### `useScrollPosition` & `useScrollDirection`
Track scroll coordinates and direction updates.

```tsx
import { useScrollPosition, useScrollDirection } from 'react-scroll-kit';

const { x, y } = useScrollPosition();
const direction = useScrollDirection({ threshold: 12 });
```

### `useInView` & `useScrollSpy`
IntersectionObserver-based hooks for scroll tracking and section highlighting.

```tsx
import { useInView, useScrollSpy } from 'react-scroll-kit';

// Track if an element is visible
const { ref, inView } = useInView({ threshold: 0.5, triggerOnce: true });

// Track active section for table of contents
const activeSection = useScrollSpy(['#home', '#pricing', '#contact'], { offset: 80 });
```

### `useInfiniteScroll`
Easily build infinite scroll feeds.

```tsx
import { useInfiniteScroll } from 'react-scroll-kit';

const { loading, sentinelRef } = useInfiniteScroll(async () => {
  await fetchMoreData();
}, { threshold: 200, hasMore: true });

return (
  <div>
    {items.map(item => <Item key={item.id} />)}
    <div ref={sentinelRef} />
  </div>
);
```

---

## 6. Accessibility & Reduced Motion

The package natively supports the `prefers-reduced-motion` media query. By default, smooth animations fall back to `instant` behaviors when requested by the user's OS.

```tsx
import { prefersReducedMotion } from 'react-scroll-kit';

if (prefersReducedMotion()) {
  // skip complex animations
}
```

---

## 7. Fixed Navbar Offset Examples

Sticky headers can sometimes hide section headers during scrolling. Use the `offset` parameter:

```tsx
scrollTo('#contact', {
  behavior: 'smooth',
  offset: 80
});
```

---

## 8. FAQ & Troubleshooting

#### Hash link does not scroll when page loads
If your layout loads resources asynchronously, use `hashScroll('#target')` which retries querying the DOM up to 10 times at 50ms intervals.

#### Scroll Restoration resets coordinates on PUSH
This is by design. Scroll restoration only triggers on history `POP` navigations (back/forward). Standard `PUSH` or `REPLACE` actions reset coordinates to `(0,0)`.

---

## 9. Performance & Bundle Info

- **Bundle Size**: ~5KB gzipped.
- **Tree-Shaking**: The library is fully tree-shakeable. Import specific modules rather than the entire namespace:
  ```tsx
  import { ScrollToTop } from 'react-scroll-kit';
  ```
- **SSR Safety**: Safe to render in Next.js/Remix (`typeof window !== 'undefined'` guards).
- **Passive Listeners & RAF**: All scroll listeners use `{ passive: true }` and `requestAnimationFrame`.

### Browser Support
- Chrome >=90
- Firefox >=88
- Safari >=14
- Edge >=90

### Migrating from `react-router-scroll-to-top`
`react-scroll-kit` is a modern replacement. Change your imports and replace `scrollToTop` with `scrollTo('top')`.
